import java.io.File
import java.util.Locale
import org.apache.spark.{SparkConf, SparkContext}

object DocSimilarity {
  def jaccard(a: Set[String], b: Set[String]): Double = {
    val union = a union b
    if (union.isEmpty) 0.0
    else (a intersect b).size.toDouble / union.size.toDouble
  }

  def main(args: Array[String]): Unit = {
    require(args.length == 3, "Usage: DocSimilarity <inputDir> <stopwordsFile> <outputDir>")
    val Array(inputDir, stopwordsPath, outputDir) = args
    val sc = new SparkContext(new SparkConf().setAppName("DocSimilarity"))
    try {
      val stopWords = sc.textFile(stopwordsPath)
        .map(_.trim.toLowerCase(Locale.ROOT)).filter(_.nonEmpty).collect().toSet
      val stopWordsBc = sc.broadcast(stopWords)

      val docs = sc.wholeTextFiles(inputDir)
        .map { case (path, content) => (new File(path).getName, content) }

      val tokens = docs.mapValues { content =>
        content.split("\\s+").filter(_.nonEmpty)
          .map(_.toLowerCase(Locale.ROOT))
          .filterNot(stopWordsBc.value.contains)
          .filter(_.length > 1).toList
      }

      val tokenSets = tokens.mapValues(_.toSet).cache()
      val scores = tokenSets.cartesian(tokenSets)
        .filter { case ((d1, _), (d2, _)) => d1 < d2 }
        .map { case ((d1, set1), (d2, set2)) => (d1, d2, jaccard(set1, set2)) }

      implicit val bestFirst: Ordering[(String, String, Double)] =
        Ordering.fromLessThan { (x, y) =>
          if (x._3 != y._3) x._3 > y._3
          else if (x._1 != y._1) x._1 < y._1
          else x._2 < y._2
        }
      val top20 = scores.takeOrdered(20)
      val lines = top20.map { case (d1, d2, score) => f"$d1,$d2,$score%.4f" }
      lines.foreach(println)
      sc.parallelize(lines, 1).saveAsTextFile(outputDir)
    } finally {
      sc.stop()
    }
  }
}
